<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>List comment</title>
	<link rel="stylesheet" href="public/bootstrap-3.3.7-dist/css/bootstrap.min.css">
</head>
<body>
<div class="all-comment">
	<div class="row">
		<div class="col-md-6">
			<div class="comment" style="padding: 10px 0; margin: 5px 0;">
				<div class="name-user" style="font-weight: bold; font-size: 18px; margin-bottom: 8px">
					Đình Cường
				</div>

				<div class="date">
					22/12/2018
				</div>

				<div class="review">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellendus illum quo, molestias excepturi quibusdam sunt amet provident ratione, consectetur laboriosam iusto, asperiores minus libero porro facilis recusandae maiores tenetur, tempora.
				</div>



			</div>
		</div>

		<div class="col-md-6">
			<div class="comment" style="padding: 10px 0; margin: 5px 0;">
				<div class="name-user" style="font-weight: bold; font-size: 18px; margin-bottom: 8px">
					Đình Cường
				</div>

				<div class="date">
					22/12/2018
				</div>

				<div class="review">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellendus illum quo, molestias excepturi quibusdam sunt amet provident ratione, consectetur laboriosam iusto, asperiores minus libero porro facilis recusandae maiores tenetur, tempora.
				</div>



			</div>
		</div>

		<div class="col-md-6">
			<div class="comment" style="padding: 10px 0; margin: 5px 0;">
				<div class="name-user" style="font-weight: bold; font-size: 18px; margin-bottom: 8px">
					Đình Cường
				</div>

				<div class="date">
					22/12/2018
				</div>

				<div class="review">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellendus illum quo, molestias excepturi quibusdam sunt amet provident ratione, consectetur laboriosam iusto, asperiores minus libero porro facilis recusandae maiores tenetur, tempora.
				</div>



			</div>
		</div>

		<div class="col-md-6">
			<div class="comment" style="padding: 10px 0; margin: 5px 0;">
				<div class="name-user" style="font-weight: bold; font-size: 18px; margin-bottom: 8px">
					Đình Cường
				</div>

				<div class="date">
					22/12/2018
				</div>

				<div class="review">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellendus illum quo, molestias excepturi quibusdam sunt amet provident ratione, consectetur laboriosam iusto, asperiores minus libero porro facilis recusandae maiores tenetur, tempora.
				</div>



			</div>
		</div>
	</div>

</div>
</body>
</html>